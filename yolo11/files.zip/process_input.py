# yolo11/process_input.py
from pathlib import Path
from .config import load_config
from .inference import predict

_cfg = load_config()

def process_path(path, task=None, target_fps=None):
    """
    Point d'entrée public du pipeline.
    Délègue à predict() qui dispatche automatiquement
    selon la nature de l'input (vidéo / image / dossier).
    """
    if task is None:
        task = _cfg["tasks"]
    return predict(str(path), tasks=task, target_fps=target_fps)
