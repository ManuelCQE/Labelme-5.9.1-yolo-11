# yolo11/inference.py
import os
from pathlib import Path
from typing import List, Dict, Any, Optional

from PIL import Image
import cv2
import numpy as np

from .coco import COCO_SKELETON, COCO_COLORS
from .model import get_model
from .process_input_helpers import save_labelme_json, _boxes_to_shapes, _masks_to_shapes, _keypoints_to_shapes
from .tracking.kalman_tracker import KalmanTracker
from .config import load_config

VIDEO_EXTENSIONS = {".mp4", ".avi", ".mov", ".mkv", ".wmv", ".flv", ".webm"}
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"}

# ----------------------------
# Helpers : dessin
# ----------------------------
def _safe_txt(label: Optional[str], gid: Optional[Any]) -> str:
    return f"{label or ''} {gid}" if gid is not None else (label or "").strip()

def draw_shapes_on_frame(frame: np.ndarray, shapes: List[Dict[str, Any]]) -> np.ndarray:
    """Dessine rectangles, masques et skeletons sur la frame."""
    joint_color = COCO_COLORS.get("joint", (0, 180, 255))
    bone_color  = COCO_COLORS.get("bone",  (0, 120, 255))
    box_color   = COCO_COLORS.get("box",   (0, 200, 0))
    mask_color  = COCO_COLORS.get("mask",  (0, 0, 255))
    label_bg    = COCO_COLORS.get("label_bg",  (0, 0, 0))
    label_txt   = COCO_COLORS.get("label_txt", (255, 255, 255))
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale, thickness_txt, pad = 0.55, 1, 4

    for s in shapes:
        gid        = s.get("group_id")
        label      = s.get("label", "") or ""
        shape_type = s.get("shape_type")
        txt        = _safe_txt(label, gid)

        if shape_type == "rectangle":
            try:
                x1, y1 = map(int, s["points"][0])
                x2, y2 = map(int, s["points"][1])
                cv2.rectangle(frame, (x1, y1), (x2, y2), box_color, 2)
                if txt:
                    (w, h), _ = cv2.getTextSize(txt, font, font_scale, thickness_txt)
                    tx, ty = x1, max(0, y1 - h - 2*pad)
                    cv2.rectangle(frame, (tx, ty), (tx + w + 2*pad, ty + h + 2*pad), label_bg, -1)
                    cv2.putText(frame, txt, (tx + pad, ty + h + pad//2), font, font_scale, label_txt, thickness_txt, cv2.LINE_AA)
            except Exception:
                continue

        elif shape_type == "polygon":
            try:
                pts = np.array(s["points"], np.int32).reshape((-1, 1, 2))
                cv2.polylines(frame, [pts], True, mask_color, 2)
                if txt:
                    cx, cy = int(np.mean(pts[:,0,0])), int(np.mean(pts[:,0,1]))
                    (w, h), _ = cv2.getTextSize(txt, font, font_scale, thickness_txt)
                    tx, ty = cx - w//2 - pad, max(0, cy - h//2 - pad)
                    cv2.rectangle(frame, (tx, ty), (tx + w + 2*pad, ty + h + 2*pad), label_bg, -1)
                    cv2.putText(frame, txt, (tx + pad, ty + h + pad//2), font, font_scale, label_txt, thickness_txt, cv2.LINE_AA)
            except Exception:
                continue

        elif shape_type in ["point", "skeleton"]:
            pts = s.get("points", [])
            if not pts:
                continue
            for p in pts:
                try:
                    cv2.circle(frame, (int(p[1]), int(p[2])), 4, joint_color, -1)
                except Exception:
                    continue
            for a, b in COCO_SKELETON:
                if a < len(pts) and b < len(pts):
                    xa, ya = pts[a][1], pts[a][2]
                    xb, yb = pts[b][1], pts[b][2]
                    try:
                        if all(np.isfinite(v) for v in [xa, ya, xb, yb]):
                            cv2.line(frame, (int(xa), int(ya)), (int(xb), int(yb)), bone_color, 2)
                    except Exception:
                        continue
            if txt:
                try:
                    x0, y0 = int(pts[0][1]), int(pts[0][2])
                    (w, h), _ = cv2.getTextSize(txt, font, font_scale, thickness_txt)
                    tx, ty = x0 - w//2 - pad, max(0, y0 - h - 2*pad)
                    cv2.rectangle(frame, (tx, ty), (tx + w + 2*pad, ty + h + 2*pad), label_bg, -1)
                    cv2.putText(frame, txt, (tx + pad, ty + h + pad//2), font, font_scale, label_txt, thickness_txt, cv2.LINE_AA)
                except Exception:
                    pass
    return frame


# ----------------------------
# Fonctionnalité 1 : detect_frame
# ----------------------------
def detect_frame(
    frame: np.ndarray,
    mdl_boxes,
    mdl_seg,
    mdl_skeletons,
    allowed_classes: set,
    tracker=None,
) -> Dict[str, List]:
    """
    Inférence YOLO (boxes + seg + skeletons) sur une frame,
    corrélation spatiale et héritage label/track_id.
    Le tracker est optionnel (None pour les images).
    Retourne raw_boxes, raw_masks, raw_skeletons.
    """

    # --- 1. BOXES (toujours) ---
    raw_boxes = []
    r_boxes = mdl_boxes(frame, verbose=False)
    bb = r_boxes[0].boxes
    if bb is not None and len(bb) > 0:
        for b, c in zip(bb.xyxy.cpu().numpy(), bb.cls):
            lbl = mdl_boxes.names[int(c)]
            if allowed_classes and lbl not in allowed_classes:
                continue
            raw_boxes.append({"bbox": b.tolist(), "label": lbl})

    # --- 2. TRACKING (optionnel) ---
    if tracker and raw_boxes:
        tracked_ids = tracker.update([b["bbox"] for b in raw_boxes])
    else:
        tracked_ids = list(range(len(raw_boxes)))

    for i, box in enumerate(raw_boxes):
        tid = tracked_ids[i] if i < len(tracked_ids) else i
        box["track_id"]   = tid
        box["label_full"] = f"{box['label']}_{tid}"

    # --- Helper : box contenante ---
    def find_parent_box(x, y):
        for box in raw_boxes:
            bx1, by1, bx2, by2 = box["bbox"]
            if bx1 <= x <= bx2 and by1 <= y <= by2:
                return box
        return None

    # --- 3. SEGMENTATION ---
    raw_masks = []
    if mdl_seg:
        r_seg   = mdl_seg(frame, verbose=False)
        mm      = getattr(r_seg[0], "masks", None)
        seg_cls = r_seg[0].boxes.cls.cpu().numpy() if r_seg[0].boxes is not None else []
        if mm is not None:
            for i, poly in enumerate(getattr(mm, "xy", [])):
                if i < len(seg_cls) and int(seg_cls[i]) != 0:
                    continue
                pts = [[float(x), float(y)] for x, y in
                       (poly.tolist() if hasattr(poly, "tolist") else poly)]
                if not pts:
                    continue
                cx = sum(p[0] for p in pts) / len(pts)
                cy = sum(p[1] for p in pts) / len(pts)
                parent = find_parent_box(cx, cy)
                raw_masks.append({
                    "points":   pts,
                    "label":    parent["label_full"] if parent else "person",
                    "track_id": parent["track_id"]   if parent else None,
                })

    # --- 4. SKELETONS ---
    raw_skeletons = []
    if mdl_skeletons:
        r_sk     = mdl_skeletons(frame, verbose=False)
        kp       = getattr(r_sk[0], "keypoints", None)
        if kp is not None:
            sk_array = kp.xy.cpu().numpy()    # (N, 17, 2)
            sk_conf  = kp.conf.cpu().numpy()  # (N, 17)
            for inst, conf in zip(sk_array, sk_conf):
                kpts = [
                    [float(i), float(x), float(y), float(c)]
                    for i, ((x, y), c) in enumerate(zip(inst, conf))
                ]
                if not kpts:
                    continue
                visible = [(k[1], k[2]) for k in kpts if k[3] > 0.2]
                if not visible:
                    continue
                sx, sy = visible[0]
                parent = find_parent_box(sx, sy)
                raw_skeletons.append({
                    "keypoints": kpts,
                    "label":     parent["label_full"] if parent else "skeleton",
                    "track_id":  parent["track_id"]   if parent else None,
                })

    return {
        "raw_boxes":     raw_boxes,
        "raw_masks":     raw_masks,
        "raw_skeletons": raw_skeletons,
    }


# ----------------------------
# Fonctionnalité 2 : build_shapes
# ----------------------------
def build_shapes(
    detection: Dict[str, List],
    requested_tasks: set,
) -> List[Dict]:
    """
    Construit les shapes LabelMe depuis les entités détectées.
    """
    raw_boxes     = detection["raw_boxes"]
    raw_masks     = detection["raw_masks"]
    raw_skeletons = detection["raw_skeletons"]
    shapes = []

    if "boxes" in requested_tasks:
        shapes += _boxes_to_shapes(
            [b["bbox"]       for b in raw_boxes],
            [b["label_full"] for b in raw_boxes],
        )

    if "segmentation" in requested_tasks:
        shapes += _masks_to_shapes(
            [m["points"] for m in raw_masks],
            labels=[m["label"] for m in raw_masks],
        )

    if "skeletons" in requested_tasks:
        for sk in raw_skeletons:
            shapes += _keypoints_to_shapes(
                sk["keypoints"],
                group_id=sk["track_id"],
                label=sk["label"],
            )

    return shapes


# ----------------------------
# Point d'entrée unifié : predict
# ----------------------------
def predict(
    input_path: str,
    tasks=None,
    target_fps: float = None,
    use_tracker: bool = True,
):
    """
    Point d'entrée unifié.
    Détecte automatiquement la nature de l'input :
      - vidéo  → boucle frames + tracker
      - image  → détection simple, pas de tracker
      - dossier → boucle images, pas de tracker
    """
    cfg             = load_config()
    allowed_classes = set(cfg.get("classes") or [])

    path = Path(input_path)

    # Normalisation des tâches
    tasks = tasks or []
    if "everything" in tasks:
        tasks = ["boxes", "segmentation", "skeletons"]
    requested_tasks = set(tasks)

    # Chargement modèles — boxes toujours chargé
    mdl_boxes     = get_model("boxes")
    mdl_seg       = get_model("segmentation") if "segmentation" in requested_tasks else None
    mdl_skeletons = get_model("skeletons")    if "skeletons"    in requested_tasks else None

    # Dossier de sortie
    out_dir = os.path.join(
        str(path.parent),
        cfg.get("output", {}).get("processed_dirname", "processed")
    )
    os.makedirs(out_dir, exist_ok=True)

    # -------------------------------------------------------
    # CAS 1 : VIDÉO
    # -------------------------------------------------------
    if path.suffix.lower() in VIDEO_EXTENSIONS:
        return _predict_video(
            path, out_dir, cfg,
            mdl_boxes, mdl_seg, mdl_skeletons,
            allowed_classes, requested_tasks,
            target_fps, use_tracker,
        )

    # -------------------------------------------------------
    # CAS 2 : DOSSIER D'IMAGES
    # -------------------------------------------------------
    elif path.is_dir():
        images = sorted([
            f for f in path.iterdir()
            if f.suffix.lower() in IMAGE_EXTENSIONS
        ])
        print(f"[DOSSIER] {len(images)} images trouvées dans {path}")
        results = []
        for idx, img_path in enumerate(images):
            r = _predict_single_image(
                img_path, out_dir, idx,
                mdl_boxes, mdl_seg, mdl_skeletons,
                allowed_classes, requested_tasks,
            )
            results.append(r)
        print(f"[DOSSIER] {len(results)} images traitées.")
        return {"images_processed": len(results), "output_dir": out_dir}

    # -------------------------------------------------------
    # CAS 3 : IMAGE SEULE
    # -------------------------------------------------------
    elif path.suffix.lower() in IMAGE_EXTENSIONS:
        r = _predict_single_image(
            path, out_dir, 0,
            mdl_boxes, mdl_seg, mdl_skeletons,
            allowed_classes, requested_tasks,
        )
        return r

    else:
        raise ValueError(f"Input non reconnu : {input_path}")


# ----------------------------
# Interne : traitement image unique
# ----------------------------
def _predict_single_image(
    img_path: Path,
    out_dir: str,
    idx: int,
    mdl_boxes, mdl_seg, mdl_skeletons,
    allowed_classes: set,
    requested_tasks: set,
) -> Dict:
    frame = cv2.imread(str(img_path))
    if frame is None:
        print(f"[IMAGE] Impossible de lire {img_path}, ignorée.")
        return {}

    h, w = frame.shape[:2]

    detection = detect_frame(
        frame,
        mdl_boxes, mdl_seg, mdl_skeletons,
        allowed_classes,
        tracker=None,  # pas de tracker pour les images
    )

    shapes = build_shapes(detection, requested_tasks)

    img_name  = f"{img_path.stem}_annotated{img_path.suffix}"
    json_name = f"{img_path.stem}_annotated.json"
    out_img   = os.path.join(out_dir, img_name)
    out_json  = os.path.join(out_dir, json_name)

    cv2.imwrite(out_img, frame)
    save_labelme_json(out_img, shapes, w, h, out_json)

    print(f"[IMAGE] {img_path.name} → {len(shapes)} shapes exportées")
    return {"image": out_img, "json": out_json, "shapes": len(shapes)}


# ----------------------------
# Interne : traitement vidéo
# ----------------------------
def _predict_video(
    path: Path,
    out_dir: str,
    cfg: dict,
    mdl_boxes, mdl_seg, mdl_skeletons,
    allowed_classes: set,
    requested_tasks: set,
    target_fps: float,
    use_tracker: bool,
) -> Dict:
    print(f"[VIDEO] Chargement : {path}")
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise RuntimeError(f"Impossible d'ouvrir la vidéo : {path}")

    orig_fps    = cap.get(cv2.CAP_PROP_FPS)
    orig_width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    orig_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    print(f"[VIDEO] {orig_fps:.1f}fps — {total_frames} frames — {orig_width}x{orig_height}")

    # Sampling
    sample_interval = 1
    if target_fps and target_fps > 0:
        sample_interval = max(1, int(orig_fps / target_fps))
    print(f"[VIDEO] Export 1 frame toutes les {sample_interval} frames")

    # Vidéo annotée en sortie
    out_video_path = os.path.join(out_dir, "annotated_video.mp4")
    fourcc     = cv2.VideoWriter_fourcc(*"mp4v")
    out_writer = cv2.VideoWriter(
        out_video_path, fourcc,
        float(target_fps or orig_fps),
        (orig_width, orig_height)
    )

    # Tracker
    tracker = KalmanTracker(
        iou_thresh=0.3,
        max_missed_seconds=2.0,
        source_fps=orig_fps,
        sample_interval=1,  # tracker voit toutes les frames
    ) if use_tracker else None

    frame_idx  = 0
    export_idx = 0

    print("[VIDEO] Début traitement...")

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_idx += 1

        # Détection + corrélation + tracking sur TOUTES les frames
        detection = detect_frame(
            frame,
            mdl_boxes, mdl_seg, mdl_skeletons,
            allowed_classes,
            tracker=tracker,
        )

        # Sampling — export seulement les frames cibles
        if frame_idx % sample_interval != 0:
            continue

        # Construction shapes
        shapes = build_shapes(detection, requested_tasks)

        # Export image + JSON + vidéo annotée
        img_name  = f"frame_{export_idx:06d}.jpg"
        json_name = f"frame_{export_idx:06d}.json"
        img_path  = os.path.join(out_dir, img_name)
        json_path = os.path.join(out_dir, json_name)

        cv2.imwrite(img_path, frame)
        save_labelme_json(img_path, shapes, orig_width, orig_height, json_path)

        annotated = draw_shapes_on_frame(frame.copy(), shapes)
        out_writer.write(annotated)

        export_idx += 1

    cap.release()
    out_writer.release()
    print(f"[VIDEO] Fin — {export_idx} frames exportées.")

    return {
        "frames_exported": export_idx,
        "fps_used":        target_fps or orig_fps,
        "output_video":    out_video_path,
        "output_dir":      out_dir,
    }
